<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    
    <title>Iniciar Sesión</title>

    <!-- Scripts -->
    


    
<!-- Custom fonts for this template-->

<script src="https://kit.fontawesome.com/f37ec6fd07.js" crossorigin="anonymous"></script>
<link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

<!-- Custom styles for this template-->
<link href="<?php echo e(asset('/dashboard-archivos/css/sb-admin-2.min.css')); ?>" rel="stylesheet">



</head>
<body>
    <div id="app">
        

        <main class="py-4">

            <?php echo $__env->yieldContent('content'); ?>
        
        </main>
    </div>

    <?php echo $__env->yieldContent('scipts'); ?>

</body>
</html>


<?php /**PATH C:\Users\Alan CL\Desktop\RESIDENCIAS PROYECYO\palmarket\resources\views/layouts/app.blade.php ENDPATH**/ ?>