<?php $__env->startSection('head'); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.1/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/croppie/2.6.2/croppie.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/croppie/2.6.2/croppie.js"></script>



<?php $__env->stopSection(); ?>







   




    
    
    

    






<?php $__env->startSection('ofertasimg'); ?>
    
    <button class="btn btn-sm btn-primary ml-auto mr-auto" style="float: right" data-toggle="modal" data-target="#modalAgregarP">
      <i class="fas fa-plus fa-sm text-white-50"></i>Nueva imagen</button>

    <h1 class="h3 mb-2 text-gray-800">Ofertas Imagenes</h1>
    <p class="mb-4">Bienvenido a ofertas.</p>




    <div class="modal-body">

      
      <div class="row">
          <?php if($message = Session::get('Listo')): ?>
              <div class="col-12 alert alert-success alert-dismissable fade show" role="alert">
                  <h5>Correcto</h5>
              <span><?php echo e($message); ?></span>   
              </div>    
      
          <?php endif; ?>
      
      </div>
    
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
      <div class="card-header py-3">
        
      </div>
      <div class="card-body">
        <div class="table-responsive">
          <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
            <thead>
              <tr>
                <th>ID</th>
                <th>Usuario</th>
                <th>Archivo</th>
                <th>Imagen</th>
                <th>Acciones</th>
            </thead>
            
              <tfoot>
                <th>ID</th>
                <th>Usuario</th>
                <th>Archivo</th>
                <th>Imagen</th>
                <th>Acciones</th>
              </tfoot>
    
            <?php $__currentLoopData = $ofertaimg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $oi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td><?php echo e($oi ->id); ?></td>
                            <td><?php echo e($oi ->Usernombre); ?></td>
                            <td><?php echo e($oi ->nombre); ?></td>
                            <td>
                              
                            <img class="ml-auto mr-auto" style="height: 50px; widht: 60;" src="<?php echo e(asset('/ofertas/img/'.$oi ->nombre)); ?>" alt="">
    
                            </td> 
                            <td>
                                
                              <button class="btn btn-info  btnEditar" 
                              
                              data-id="<?php echo e($oi->id); ?>" 
                              data-id_user="<?php echo e($oi->id_user); ?>" 
                              data-nombre="<?php echo e($oi->nombre); ?>" 
                              
                        
                              data-toggle="modal" data-target="#modalEditar">
                          <i class="fa fa-edit"></i></button>  
                        
                                    <button class="btn btn-danger  btnEliminar" data-id="<?php echo e($oi->id); ?>" data-toggle="modal" data-target="#modalEliminar">
                                      <i class="fa fa-trash"></i></button>
                                                
                                                <form action="<?php echo e(url('/dash/admin/ofertasimg', ['id'=>$oi->id] )); ?>" method="POST" id="formEli_<?php echo e($oi->id); ?>">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="id" value="<?php echo e($oi->id); ?>">
                                                    <input type="hidden" name="_method" value="delete">
                                                </form>
                                    
                            </td>
                          </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
          
          
                
    
    
            
             
            </tbody>
          </table>
        </div>
      </div>
    </div>
    
    
    
    
    
    
    </div>



 <!-- Modal Agregar -->
 <div class="modal fade" id="modalAgregarP" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Agregar producto</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>

      <form action="/dash/admin/ofertasimg" method="POST" enctype="multipart/form-data">
          
        <?php echo csrf_field(); ?>
          <div class="modal-body">

              
              <div class="row">
                  <?php if($message = Session::get('ErrorInsert')): ?>
                      <div class="col-12 alert alert-danger alert-dismissable fade show" role="alert">
                          <h5>Errores:</h5>
                          <ul>
                              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <li><?php echo e($error); ?></li>                    
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                          </ul>    
                      </div>    
              
                  <?php endif; ?>
              
              </div>
              

              <div class="form-group">
              <input type="text" class="form-control" id="id_user" name="id_user" placeholder="Usuario" value="1">
              </div>


           
              

          </div>

          

      </form>

      
    
<div class="row">

<div class="col-md-12 text-center">
  <label   class="col-lg-12 col-md-12 col-sm-12">Imagen</label>
<div id="upload-demo"></div>
</div>
</div>


<div class="row">
<div class="col-md-12 text-center" style="padding:5%;">
<strong>Seleccione una imagen:</strong>

<input name="" type="file" id="image_file">

<div class="btn-group mt-4 d-flex w-100" role="group" >
  <button class="btn btn-primary upload-image " style="float: right !important;">Guardar</button>
<button class="btn btn-secondary "  data-dismiss="modal" style="float: right !important;">Cerrar</button>

</div>

</div> 
</div>







    </div>
  </div>

</div>


<!-- Modal Editar -->
<div class="modal fade" id="modalEditar" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Agregar producto</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>

      <form action="/dash/admin/ofertasimg/editar" method="POST" enctype="multipart/form-data">
          
        <?php echo csrf_field(); ?>
          <div class="modal-body">

              
              <div class="row">
                  <?php if($message = Session::get('ErrorInsert')): ?>
                      <div class="col-12 alert alert-danger alert-dismissable fade show" role="alert">
                          <h5>Errores:</h5>
                          <ul>
                              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <li><?php echo e($error); ?></li>                    
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                          </ul>    
                      </div>    
              
                  <?php endif; ?>
              
              </div>
              
              
              <div class="form-group">
                <input type="text" class="form-control" id="idEdit" name="" placeholder="Id" >
              </div>

              <div class="form-group">
                  <input type="text" class="form-control" id="id_userEdit" name="" placeholder="Usuario" >
              </div>

              <div class="form-group">
                <input type="text" class="form-control" id="nombreEdit" name="" placeholder="Nombre" >
              </div>

              

           
              

          </div>

          

      </form>

      
    
    <div class="row">
        
      <div class="col-md-12 text-center">
        <label   class="col-lg-12 col-md-12 col-sm-12">Imagen</label>
      <div id="Edit-demo"></div>
      </div>
    </div>


    <div class="row">
      <div class="col-md-12 text-center" style="padding:5%;">
      <strong>Seleccione una imagen:</strong>
    
      <input name="" type="file" id="image_fileEdit">

      <div class="btn-group mt-4 d-flex w-100" role="group" >
        <button class="btn btn-primary edit-image " style="float: right !important;">Guardar</button>
      <button class="btn btn-secondary "  data-dismiss="modal" style="float: right !important;">Cerrar</button>
      
      </div>
      
      </div> 
    </div>






    </div>
  </div>

</div>

      <!-- Modal Eliminar -->
<div class="modal fade" id="modalEliminar" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Eliminar oferta (imagen)</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>

      
          <div class="modal-body">
                
                <h5 class="mb-3 mt-3">¿Desea eliminar la imagen?</h5>

                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                    <button type="button" class="btn btn-danger btnModalEliminar">Eliminar</button>
                </div>

          </div>

    

    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>




<?php $__env->startSection('scripts'); ?>

<script src="<?php echo e(asset('/js/croppie.js')); ?>"></script>

<script>
 



  var resize = $('#upload-demo').croppie({
      enableExif: true,
      enableOrientation: true,    
      viewport: { // Default { width: 100, height: 100, type: 'square' } 
          width: 400,
          height: 300,
          type: 'square' //square,circle
      },
      boundary: {
          width: 500,
          height: 400
      }
  });
  
  $('#image_file').on('change', function () { 
    var reader = new FileReader();
      reader.onload = function (e) {
        resize.croppie('bind',{
          url: e.target.result
        }).then(function(){
          console.log('jQuery bind complete');
        });
      }
      reader.readAsDataURL(this.files[0]);
  });


//$('.upload-image').click(function() {
    //$('.upload-image').click();
  //  console.log('gg');
//});

  $('.upload-image').on('click', function (ev) {
    resize.croppie('result', {
      type: 'canvas',
      size: 'viewport'
      

    }).then(function (img) {
    
      $.ajax({
      url: "<?php echo e(route('croppie.subir-image')); ?>",
      type: "POST",
      data: {"image":img, 

        "nombre":$('#nombreEdit').val(),
        "id_user":$('#id_user').val(),
        "_token":$('input[name="_token"]').val()
        

       },
    
      success: function (data) {
        console.log(data);

          if (data.status == true) {
            location.href="/dash/admin/ofertasimg";
          }
        }
        
       });
       
    });
  });



//////////////////////////////////////////////////////////////////////////////////
var resize2 = $('#Edit-demo').croppie({
      enableExif: true,
      enableOrientation: true,    
      viewport: { // Default { width: 100, height: 100, type: 'square' } 
          width: 400,
          height: 300,
          type: 'square' //square,circle
      },
      boundary: {
          width: 500,
          height: 400
      }
  });
  
  $('#image_fileEdit').on('change', function () { 
    var reader = new FileReader();
      reader.onload = function (e) {
        resize2.croppie('bind',{
          url: e.target.result
        }).then(function(){
          console.log('jQuery bind complete');
        });
      }
      reader.readAsDataURL(this.files[0]);
  });

  $('.edit-image').on('click', function (ev) {
    resize2.croppie('result', {
      type: 'canvas',
      size: 'viewport'
      

    }).then(function (img) {
    
      $.ajax({
      url: "<?php echo e(route('croppie.editarOferta-image')); ?>",
      type: "POST",
      data: {"image":img, 
        //Enviar datos por AJAX
        "id":$('#idEdit').val(),
        "id_user":$('#id_userEdit').val(),
        "nombre":$('#nombreEdit').val(),
        "_token":$('input[name="_token"]').val()
        

       },
    
      success: function (data) {
        console.log(data);

          if (data.status == true) {
            location.href="/dash/admin/ofertasimg";
          }
        }
        
       });
       
    });
    
  });



//Cargar datos en el formulario
  $(".btnEditar").click(function(){ 

$("#id_Edit").val($(this).data('id'));
$("#id_userEdit").val($(this).data('id_user'));
$("#nombreEdit").val($(this).data('nombre'));

});

</script>







  <script>
      $(document).ready(function(){
        <?php if($message = Session::get('ErrorInsert')): ?>
                $("#modalAgregarP").modal('show');  
        
            <?php endif; ?>
      });


      var idEliminar=0;

    $(".btnEliminar").click(function(){      
     idEliminar = $(this).data('id');
    });


    $(".btnModalEliminar").click(function(){ 
     $("#formEli_"+idEliminar).submit();
    });
//**************************************************************************************


  </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Alan CL\Desktop\RESIDENCIAS PROYECYO\palmarket\resources\views/dashboard/ofertas/ofertasimg.blade.php ENDPATH**/ ?>