<?php $__env->startSection('roles'); ?>


<a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm ml-auto mr-auto" 
style="float: right" data-toggle="modal" data-target="#modalAgregarC"><i class="fas fa-plus fa-sm text-white-50"></i> Nuevo Rol</a>
<h1 class="h3 mb-2 text-gray-800">Roles</h1>
<p class="mb-4">Bienvenido a roles.</p>



<div class="row">
    <?php if($message = Session::get('Listo')): ?>
        <div class="col-12 alert alert-success alert-dismissable fade show" role="alert">
            <h5>Correcto</h5>
        <span><?php echo e($message); ?></span>   
        </div>    

    <?php endif; ?>

</div>

<div class="modal-body">
<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
      
    </div>
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th>ID</th>
              <th>Registrado por:</th>
              <th>Descripcion</th>
              <th>Acciones</th>
          </thead>
          
          <tfoot>
            
          </tfoot>
  
          <?php $__currentLoopData = $role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td><?php echo e($rol ->id); ?></td>
                          <td><?php echo e($rol ->Usernombre); ?></td>
                          <td><?php echo e($rol ->descripcion); ?></td>
                          <td>
                              
                            <?php if($rol->id != '2' || $rol->id != '1'): ?>
                                
                            
                                    <button class="btn btn-info  btnEditar" 
                                      
                                        data-id="<?php echo e($rol->id); ?>" 
                                        data-id_user="<?php echo e($rol->id_user); ?>"
                                        data-descripcion="<?php echo e($rol->descripcion); ?>" 
                                  
                                        data-toggle="modal" data-target="#modalEditar">

                                        <i class="fa fa-edit"></i>
                                    </button>
                            <?php endif; ?>

                      
                                  <button class="btn btn-danger  btnEliminar" data-id="<?php echo e($rol->id); ?>" data-toggle="modal" data-target="#modalEliminar">
                                    <i class="fa fa-trash"></i></button>
                                    
                                    
                                      <form action="<?php echo e(url('/dash/admin/roles', ['id'=>$rol->id] )); ?>" method="POST" id="formEli_<?php echo e($rol->id); ?>">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="id" value="<?php echo e($rol->id); ?>">
                                            <input type="hidden" name="_method" value="delete">
                                      </form>
                                  
                          </td>
                        </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
        
        
              
  
  
          
           
          </tbody>
        </table>
      </div>
    </div>
  </div>

</div>

    <!-- Modal Agregar -->
    <div class="modal fade" id="modalAgregarC" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Agregar rol</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
    

            <form action="/dash/admin/roles" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
    
                    
                    <div class="row">
                        <?php if($message = Session::get('ErrorInsert')): ?>
                            <div class="col-12 alert alert-danger alert-dismissable fade show" role="alert">
                                <h5>Errores:</h5>
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>                    
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                                </ul>    
                            </div>    
                    
                        <?php endif; ?>
                    
                    </div>
                    
    
                    <div class="form-group">
                    <input type="hidden" class="form-control" name="id_user" placeholder="Usuario" value="<?php echo e(Auth::user()->id); ?>">
                    </div>

                    <div class="form-group">
                    <input type="text" class="form-control" name="descripcion" placeholder="Descripción" value="<?php echo e(old('descripcion')); ?>">
                    </div>
    
    
                    
                </div>
    
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </div>
    
            </form>
    
          </div>
        </div>
      </div>

  <!-- Modal Eliminar -->
  <div class="modal fade" id="modalEliminar" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Eleminar Rol</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
  
        
            <div class="modal-body">
                  
                  <h5 class="mb-3 mt-3">¿Desea eliminar el rol?</h5>
  
                  <div class="modal-footer">
                      <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                      <button type="button" class="btn btn-danger btnModalEliminar">Eliminar</button>
                  </div>
  
            </div>
  
      
  
      </div>
    </div>
  </div>




 <!-- Modal Agregar -->
 <div class="modal fade" id="modalEditar" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Agregar rol</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>


      <form action="/dash/admin/roles/editar" method="POST">
          <?php echo csrf_field(); ?>
          <div class="modal-body">

              
              <div class="row">
                  <?php if($message = Session::get('ErrorInsert')): ?>
                      <div class="col-12 alert alert-danger alert-dismissable fade show" role="alert">
                          <h5>Errores:</h5>
                          <ul>
                              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <li><?php echo e($error); ?></li>                    
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                          </ul>    
                      </div>    
              
                  <?php endif; ?>
              
              </div>
              
              <div class="form-group">
                <input type="hidden" name="id" id="idEdit">
              </div>

              <div class="form-group">
                <input type="hidden" class="form-control" name="id_user" placeholder="Usuario" value="<?php echo e(Auth::user()->id); ?>">
              </div>

              <div class="form-group">
                <input type="text" class="form-control" name="descripcion" id="descripcionEdit" placeholder="Descripción" value="<?php echo e(old('descripcion')); ?>">
              </div>


              
          </div>

          <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
              <button type="submit" class="btn btn-primary">Guardar</button>
          </div>

      </form>

    </div>
  </div>
</div>


<?php $__env->stopSection(); ?>





<?php $__env->startSection('scripts'); ?>

  <script>
      $(document).ready(function(){
        <?php if($message = Session::get('ErrorInsert')): ?>
                $("#modalAgregarC").modal('show');  
        
            <?php endif; ?>
      });


      var idEliminar=0;

$(".btnEliminar").click(function(){      
 idEliminar = $(this).data('id');
});


$(".btnModalEliminar").click(function(){ 
 $("#formEli_"+idEliminar).submit();
});




//Cargar datos en el formulario
$(".btnEditar").click(function(){ 

$("#idEdit").val($(this).data('id'));
//$("#usuarioEdit").val($(this).data('id_user'));
$("#descripcionEdit").val($(this).data('descripcion'));

});



  </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Alan CL\Desktop\RESIDENCIAS PROYECYO\palmarket\ResidenciasPalmarket\resources\views/dashboard/roles/roles.blade.php ENDPATH**/ ?>