<?php $__env->startSection('principal'); ?>

    <?php if(Auth::user()->estado == 1): ?>
        <img src="<?php echo e(asset('/principal-archivos/assets/img/bg-header.png')); ?>" alt="" class="w-100 h-100 ml-auto mr-auto mt-auto mb-auto">

    <?php else: ?>
    <div class="container-fluid">
        
        <!-- 404 Error Text -->
        <div class="text-center" >
          <div class="error ml-auto mr-auto text-center mb-5" data-text="Ops">Ops</div>
          <p class="lead text-gray-800 mb-5">Su cuenta a sido bloqueda temporalmente debido a que se inflingido los terminos de uso.</p>
          <p class="text-gray-500 mb-0">Para aclaraciones o reactivar su cuenta envíe un correo electronico a <a>supportPalmarket@gmail.com</a>.</p>
          
          <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        &larr; Regresar
                                    </a>
                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                      <?php echo csrf_field(); ?>
                                  </form>
        </div>

      </div>
    <?php endif; ?>




<?php $__env->stopSection(); ?>




<?php $__env->startSection('js'); ?>


    <script>
        console.log('Si jala pero no funciona la img')
    </script>    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Alan CL\Desktop\RESIDENCIAS PROYECYO\palmarket\resources\views/dashboard/principaldash.blade.php ENDPATH**/ ?>