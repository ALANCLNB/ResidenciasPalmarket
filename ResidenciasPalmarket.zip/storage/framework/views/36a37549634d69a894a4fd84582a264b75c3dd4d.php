<!-- Modal 1-->
<div class="departamentos-modal modal fade" id="departamentosModal1" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            
            <div class="container">
                <div class="row justify-content-center" style="margin-top: 5rem;">
                    <div class="col-lg-8">
                        <div class="modal-body" style="height: 100%">


                            <!-- Lista de productos-->
                            <div class="productodepartamento">
                            <h2 class="text-uppercase" style="margin-top: 2.5rem;">Frutas y verduras</h2>
                            <div class="close-modal" data-dismiss="modal"><img src="<?php echo e(asset('/principal-archivos/assets/img/close-icon.svg')); ?>" alt="Close modal" /></div>
                            
                            <form class="form-inline my-2 my-lg-0    col-lg-12 col-md-12 col-sm-12">
                                <div class="col-lg-2 col-md-2 col-sm-1"></div>

                                    <input class="form-control mr-sm-2   col-lg-6 col-md-6 col-sm-4"  type="search" placeholder="Busca aquí productos, marcas, etc.." aria-label="Search">
                                    <button class="btn btn-outline-success my-2 my-sm-0 col-lg-2 col-md-2 col-sm-2"  type="submit">Buscar</button>
                                
                                <div class="col-lg-2 col-md-2 col-sm-1"></div> 
                            </form>

                        </div> 
                        


                        <div class="container d-block" style="margin-top: 3rem; background-color: aqua;">

                            
                                
                            
                            <div class="row no-gutters" style="background-color: RED; ">
                            
                                 
                                
                                </div>
                                
                            
                            
                        </div>

                        
                        </div> 

                                   
                    </div>  
                               
                                
                    
                            
                        </div>  
                        
                    </div> 
                </div> 
            </div>  
        </div>  
   

<?php /**PATH C:\Users\Alan CL\Desktop\RESIDENCIAS PROYECYO\palmarket\ResidenciasPalmarket\resources\views/partials/departamentosmodals.blade.php ENDPATH**/ ?>