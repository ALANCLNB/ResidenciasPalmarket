<?php $__env->startSection('qysadmin'); ?>
<?php if(Auth::user()->rol == 1): ?>

<div class="container-fluid">
 

    
    
    
        <!-- Page Heading -->
        <h1 class="h3 mb-2 text-gray-800">Quejas y sugerencias</h1>
        <p class="mb-4">Rojo: Queja, Azul: Sugerencia.</p>
       
        

        
        <div class="row">
          <?php if($message = Session::get('Eliminado')): ?>
              <div class="col-12 alert alert-success alert-dismissable fade show" role="alert">
                  <h5>Correcto</h5>
              <span><?php echo e($message); ?></span>   
              </div>    

          <?php endif; ?>

        </div>
    


        <!-- DataTales Example -->
        <div class="card shadow mb-4">
          <div class="card-header py-3">
            
          </div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                  <tr>
                  
                    <th>ID</th>
                    <th>E-mail</th>
                    <th>Contenido</th>
                    <th>Tipo</th>
                    <th>Fecha</th>
                    <th>Sucursal</th>
                    <th>Acciones</th>
                </thead>
    
                <tfoot>
                    <th>ID</th>
                    <th>E-mail</th>
                    <th>Contenido</th>
                    <th>Tipo</th>
                    <th>Fecha</th>
                    <th>Sucursal</th>
                    <th>Acciones</th>
                </tfoot>
    
                
                <?php $__currentLoopData = $qysug; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $qys): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e($qys ->id); ?></td>
                      <td><?php echo e($qys ->email); ?></td>
                      <td><?php echo e($qys ->contenido); ?></td>
                       
                       
                        <?php if($qys ->tipo=='1'): ?>
                                <td>
                                  <button class="btn btn-danger boton">Responder</button>                   
                              </td> 
                        <?php else: ?>     
                              <td>
                                <button class="btn btn-info boton">Responder</button>                   
                              </td>
                        <?php endif; ?> 
                        
                      </td>

                      <td><?php echo e($qys ->created_at); ?></td>
                      <td><?php echo e($qys ->Sucursal); ?></td>
                      

                      
                      <td>
                          
                              <a href="" class="btn btn-info "><i class="fa fa-edit"></i></a>
                  

                      <button class="btn btn-danger  btnEliminar" data-id="<?php echo e($qys->id); ?>" data-toggle="modal" data-target="#modalEliminar">
                        <i class="fa fa-trash"></i></button>
                                  
                                  <form action="<?php echo e(url('/dash/admin/qys', ['id'=>$qys->id] )); ?>" method="POST" id="formEli_<?php echo e($qys->id); ?>">
                                      <?php echo csrf_field(); ?>
                                      <input type="hidden" name="id" value="<?php echo e($qys->id); ?>">
                                      <input type="hidden" name="_method" value="delete">
                                  </form>
                      </td>
                    </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
              
                </tbody>
              </table>
            </div>
          </div>
        </div>
    
      </div>


<?php endif; ?>

<?php $__env->stopSection(); ?>





<?php $__env->startSection('qysuser'); ?>

<?php if(Auth::user()->rol == 2): ?>

<div class="container-fluid">

<h1 class="h3 mb-2 text-gray-800">Quejas y sugerencias</h1>



<div class="row">
  <?php if($message = Session::get('Listo')): ?>
      <div class="col-12 alert alert-success alert-dismissable fade show" role="alert">
          <h5>Correcto</h5>
      <span><?php echo e($message); ?></span>   
      </div>    

  <?php endif; ?>

</div>


<div class="row">
  <?php if($message = Session::get('ErrorInsert')): ?>
      <div class="col-12 alert alert-danger alert-dismissable fade show" role="alert">
          <h5>Errores:</h5>
          <ul>
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><?php echo e($error); ?></li>                    
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
          </ul>    
      </div>    

  <?php endif; ?>

</div>

<form action="/dash/admin/qys" method="POST">

            <?php echo csrf_field(); ?>

            <input type="hidden" class="form-control" name="id_user" placeholder="Usuario ID Pruebas" value="<?php echo e(Auth::user()->id); ?>">
            
            <input type="hidden" class="form-control" name="email" placeholder="email Pruebas" value="<?php echo e(Auth::user()->email); ?>">

            <div class="form-group">
              <label for="exampleFormControlTextarea1">Escriba aquí su comentario.</label>
              <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" name="contenido"></textarea>
            </div>
            
            
            <div class="col-md-3 mb-3      col-lg-10 col-md-10 col-sm-12    ml-auto mb-auto mr-auto mt-auto">
              <label for="validationCustom04">Tipo</label>
              
                  <select class="custom-select    col-lg-4 col-md-6 col-sm-10    ml-auto mb-auto mr-auto mt-auto" name="tipo" id="validationCustom04" required>
                    <option selected disabled value="">Seleccionar</option>
                    <option value="1">Queja</option>
                    <option value="2">Sugerencia</option>
                  </select>

            
              <label for="validationCustom04">Sucursal</label>
              
                  <select class="custom-select   col-lg-4 col-md-6 col-sm-10    ml-auto mb-auto mr-auto mt-auto" name="sucursal" id="validationCustom04" required>
                    <option selected disabled value="">Seleccionar</option>
                    
                    
                    <?php $__currentLoopData = $sucursales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sucursal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($sucursal->id); ?>"><?php echo e($sucursal->nombre); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                  </select>

            </div>

            <div class="     col-lg-12 col-md-12 col-sm-12    ml-auto mb-auto mr-auto mt-4" style="text-align: center">

              

                  <button type="submit" id="btnSubirPDF" class="btn btn-outline-success    col-lg-2 col-md-6 col-sm-10      ml-auto mb-auto mr-auto mt-auto" style="margin-top: 30px;">Enviar</button>

              

            </div>

  
</form>







<!-- Modal Eliminar -->
<div class="modal fade" id="modalEliminar" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Eleminar queja o sugerencia</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>

      
          <div class="modal-body">
                
                <h5 class="mb-3 mt-3">¿Desea eliminar la queja o sugerencia?</h5>

                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                    <button type="button" class="btn btn-danger btnModalEliminar">Eliminar</button>
                </div>

          </div>

    

    </div>
  </div>
</div>
</div>

<?php endif; ?>

<?php $__env->stopSection(); ?>





<?php $__env->startSection('scripts'); ?>
<script>

var idEliminar=0;

    $(".btnEliminar").click(function(){      
     idEliminar = $(this).data('id');
    });


    $(".btnModalEliminar").click(function(){ 
     $("#formEli_"+idEliminar).submit();
    });
    









</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Alan CL\Desktop\RESIDENCIAS PROYECYO\palmarket\resources\views/dashboard/qys/qys.blade.php ENDPATH**/ ?>