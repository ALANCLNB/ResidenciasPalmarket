<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Ofertasimg extends Model
{
    protected $fillable = ['id_user','nombre'];
}
