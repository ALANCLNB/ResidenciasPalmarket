<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Ofertaspdf extends Model
{
    protected $fillable = ['id_user','nombre'];
}
