<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Qy extends Model
{
 protected $fillable =['id_user','email','contenido','tipo','sucursal'];
}
